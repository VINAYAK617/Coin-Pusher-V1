﻿using System;
using GameEngine.Engine;
using Newtonsoft.Json;

namespace TicketChecker
{
    public class Checker
    {
        public delegate void ErrorFoundCallback(string errorString);

        public static ErrorFoundCallback ShowErrorCallback { get; set; }

        #region Public functions to start the check
        /// <summary>
        /// Check a ticket. Return true if an error has been found.
        /// </summary>
        public static bool CheckTicket(string jsonTicket)
        {
            if (string.IsNullOrWhiteSpace(jsonTicket))
            {
                ShowError("Ticket JSON is empty.");
                return true;
            }

            try
            {
                Ticket.Load(jsonTicket);
            }
            catch (Exception ex)
            {
                ShowError($"Ticket JSON could not be loaded by framework Ticket.Load: {ex.Message}");
                return true;
            }

            return StartCheck(jsonTicket);
        }

        /// <summary>
        /// Check a ticket. Return true if an error has been found.
        /// </summary>
        public static bool CheckTicket(Ticket ticket)
        {
            if (ticket == null)
            {
                ShowError("Ticket object is null.");
                return true;
            }

            string jsonTicket;
            try
            {
                jsonTicket = JsonConvert.SerializeObject(ticket);
            }
            catch (Exception ex)
            {
                ShowError($"Ticket object could not be serialized for Coin Pusher validation: {ex.Message}");
                return true;
            }

            return StartCheck(jsonTicket);
        }
        #endregion

        /// <summary>
        /// Start the Coin Pusher security checker. Return true if an error has been found.
        /// </summary>
        private static bool StartCheck(string jsonTicket)
        {
            CoinPusherEngine.TicketChecker.TicketCheckResult result;
            try
            {
                result = CoinPusherEngine.TicketChecker.CheckJson(jsonTicket);
            }
            catch (Exception ex)
            {
                ShowError($"Coin Pusher ticket checker crashed: {ex}");
                return true;
            }

            foreach (var error in result.Errors)
            {
                ShowError(error);
            }

            return !result.IsValid;
        }

        private static void ShowError(string error)
        {
            if (ShowErrorCallback != null)
                ShowErrorCallback(error);
        }
    }
}
